﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeChallenge.Tests.Integration.TestModel
{
    public class TestObject
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string OtherData { get; set; }
        public List<TestObject> TestObjects { get; set; }

    }

    public class TestObjectService
    {
        public List<TestObject> GetTestObjects()
        {

            var testObj = new TestObject();

            var testObjects = new List<TestObject>();

            testObj.Id = 1;
            testObj.Name = "Parent";
            testObj.OtherData = "OtherDataForParent";

            TestObject testObject = new TestObject
            {
                Id = 2,
                Name = "Child1",
                OtherData = "OtherDataForChild1",
                TestObjects = new List<TestObject> { new TestObject { Id = 3, Name = "GrandChild1", OtherData = "OtherDataForGrandChild1" },
                    new TestObject { Id = 4, Name = "GrandChild2", OtherData = "OtherDataForGrandChild2" } }
            };

            testObjects.Add(testObject);

            testObject = new TestObject { Id = 5, Name = "Child2", OtherData = "OtherDataForChild2" };

            testObjects.Add(testObject);

            testObj.TestObjects = testObjects;

            var testObjList = new List<TestObject>();
            testObjList.Add(testObj);

            return testObjList;

        }
    }

}
