﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CodeChallenge.Models;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using CodeChallenge.Data;

namespace CodeChallenge.Repositories
{
    public class EmployeeRespository : IEmployeeRepository
    {
        private readonly EmployeeContext _employeeContext;
        private readonly ILogger<IEmployeeRepository> _logger;

        public EmployeeRespository(ILogger<IEmployeeRepository> logger, EmployeeContext employeeContext)
        {
            _employeeContext = employeeContext;
            _logger = logger;
        }

        public Employee Add(Employee employee)
        {
            employee.EmployeeId = Guid.NewGuid().ToString();
            _employeeContext.Employees.Add(employee);
            return employee;
        }

        public Employee GetById(string id)
        {
            // return _employeeContext.Employees.SingleOrDefault(e => e.EmployeeId == id);

            return _employeeContext.Employees.Where(e => e.EmployeeId == id).Include(x=>x.DirectReports).SingleOrDefault();
        }

        public Task SaveAsync()
        {
            return _employeeContext.SaveChangesAsync();
        }

        public Employee Remove(Employee employee)
        {
            return _employeeContext.Remove(employee).Entity;
        }

        public ReportingStructure GetReportingStructure(string id)
        {
            var reportingStructure = new ReportingStructure();

            var employee = GetById(id);

            reportingStructure.Employee = GetById(id);
            reportingStructure.NumberOfReports = GetNumberOfReports(id);

            return reportingStructure;
        }

        private int GetNumberOfReports(string id)
        {
            var employee = GetById(id);

            if (employee.DirectReports == null)
                return 0;

            int reportCount = employee.DirectReports.Count;

            foreach (Employee directReport in employee.DirectReports)
            {
                reportCount += GetNumberOfReports(directReport.EmployeeId);
            }

            return reportCount;
        }
    }
}
