﻿using CodeChallenge.Models;
using CodeChallenge.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;

namespace CodeChallenge.Controllers
{
    [ApiController]
    [Route("api/compensation")]
    public class CompensationController : ControllerBase
    {

        private readonly ILogger _logger;
        private readonly ICompensationService _compensationService;

        public CompensationController(ILogger<EmployeeController> logger, ICompensationService compensationService)
        {
            _logger = logger;
            _compensationService = compensationService;
        }

        // [HttpGet("{id}", Name = "getCompensationById"), Authorize(Roles = "Manager")]
        [HttpGet("{id}", Name = "getCompensationById")]
        public IActionResult GetCompensationById(String id)
        {
            _logger.LogDebug($"Received compensation get request for '{id}'");

            var employee = _compensationService.GetById(id);

            if (employee == null)
                return NotFound();

            return Ok(employee);
        }

        [HttpPost]
        public IActionResult CreateCompensation([FromBody] Compensation compensation)
        {

            _compensationService.Create(compensation);

            _logger.LogDebug($"Received compensation create request for '{compensation.EmployeeId}'");

            if (null != compensation.Employee)
            {
                return CreatedAtRoute("getCompensationById", new { id = compensation.Employee.EmployeeId }, compensation);
            }

            return BadRequest();
        }

        //[HttpPut("{id}")]
        //public IActionResult UpdateCompensation(String id, [FromBody] Compensation compensation)
        //{
        //    _logger.LogDebug($"Recieved employee update request for '{id}'");

        //    var existingCompensation = _compensationService.GetById(id);
            
        //    if (existingCompensation == null)
        //        return NotFound();

        //    // Call update compensation logic

        //    return Ok(existingCompensation);
        //}
    }
}
